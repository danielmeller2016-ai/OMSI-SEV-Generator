using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Diagnostics;
static class Program {
 [STAThread] static void Main(){ApplicationConfiguration.Initialize(); Application.Run(new Window());}
}
class Window:Form {
 readonly WebView2 view=new(){Dock=DockStyle.Fill};
 readonly string dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"OMSI-SEV");
 string Store=>Path.Combine(dir,"templates.json");
 public Window(){Text="OMSI SEV Generator 3.3"; Width=1400;Height=900;Controls.Add(view);Shown+=async(_,_)=>{try{Directory.CreateDirectory(dir);var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(dir,"WebView2"));await view.EnsureCoreWebView2Async(env);var core=view.CoreWebView2;core.AddWebResourceRequestedFilter("https://sev.local/*",CoreWebView2WebResourceContext.All);core.WebResourceRequested+=Handle;core.NavigationStarting+=(s,e)=>{if(!e.Uri.StartsWith("https://sev.local/",StringComparison.Ordinal))e.Cancel=true;};core.Navigate("https://sev.local/");}catch(Exception e){MessageBox.Show(e.ToString(),"Startfehler");}};}
 void Handle(object? sender,CoreWebView2WebResourceRequestedEventArgs e){var def=e.GetDeferral();try{var path=new Uri(e.Request.Uri).AbsolutePath; string result; if(path=="/"){using var sr=new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("index.html")!);result=sr.ReadToEnd();Respond(e,result,"text/html; charset=utf-8");return;}if(path=="/templates"){if(e.Request.Method=="POST"){using var sr=new StreamReader(e.Request.Content);result=sr.ReadToEnd();using var doc=JsonDocument.Parse(result);if(doc.RootElement.ValueKind!=JsonValueKind.Array)throw new Exception("Ungültige Vorlagen");File.WriteAllText(Store+".tmp",result);File.Move(Store+".tmp",Store,true);}result=File.Exists(Store)?File.ReadAllText(Store):"[]";}else if(path=="/config")result=JsonSerializer.Serialize(new{source="https://github.com/danielmeller2016-ai/OMSI-SEV-Generator/releases/latest",status="GitHub Update-Quelle"});else if(path=="/update"){Process.Start(new ProcessStartInfo("https://github.com/danielmeller2016-ai/OMSI-SEV-Generator/releases/latest"){UseShellExecute=true});result="{\"status\":\"Release-Seite geöffnet\"}";}else if(path=="/exit"){BeginInvoke(new Action(Close));result="{}";}else result="{}";Respond(e,result,"application/json");}catch(Exception ex){Respond(e,JsonSerializer.Serialize(new{error=ex.Message}),"application/json",500);}finally{def.Complete();}}
 void Respond(CoreWebView2WebResourceRequestedEventArgs e,string body,string type,int code=200){e.Response=view.CoreWebView2.Environment.CreateWebResourceResponse(new MemoryStream(Encoding.UTF8.GetBytes(body)),code,code==200?"OK":"Error","Content-Type: "+type+"\r\nCache-Control: no-store");}
}
